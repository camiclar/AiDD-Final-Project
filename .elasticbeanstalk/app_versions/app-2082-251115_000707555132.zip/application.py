"""
Application entry point for AWS Elastic Beanstalk.
Elastic Beanstalk looks for 'application' by default.
"""
from app import create_app

# Create the Flask application
application = create_app()

if __name__ == '__main__':
    application.run()

